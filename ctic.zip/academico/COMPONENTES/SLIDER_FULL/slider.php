
    <div id="comp-slider-full">

      <div class="content_slide">

        <div id="slide1" class="slide mostrado" >
          <img class="carga-img" src="" >
        </div>

        <div id="slide2" class="slide" >
          <img class="carga-img" src="" >
        </div>

        <div id="slide3" class="slide" >
          <img class="carga-img" src="" >
        </div>

        <div id="slide4" class="slide" >
          <img class="carga-img" src="">
        </div>

      </div>

    </div>


