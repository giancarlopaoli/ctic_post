<?php 

/*		$GL_DNS="http://www.acmtechnology.com.pe/nueva_web";
		
	$GL_DNS_POST="http://www.acmtechnology.com.pe/nueva_web";


	$GL_DNS_IMG="http://www.acmtechnology.com.pe/nueva_web";
*/
	
	$GL_DNS="http://local.dantevidal.com/ERP";
		
	$GL_DNS_POST="http://local.dantevidal.com/ERP";

	$GL_DNS_IMG="http://local.dantevidal.com/ERP";
		


?>