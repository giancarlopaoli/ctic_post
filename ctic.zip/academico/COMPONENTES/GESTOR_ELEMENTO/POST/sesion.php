<?php
session_start();

$_SESSION['user']='123456789';




?>