<?php

$GL_NOMBRE_PAGINA='ACM Technology';

$GL_DIR_PAGINA='www.acmtechnology.com.pe';
$GL_HOST_MAIL='www.acmtechnology.com.pe';

$GL_USER_MAIL='web@acmtechnology.com.pe';
$GL_PASS_USER_MAIL='acm123456tech';
		
$GL_RECEPTOR_MAIL='web@acmtechnology.com.pe';		

?>