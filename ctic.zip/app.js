// Creación del módulo
var angularRoutingApp = angular.module('angularRoutingApp', ['ngRoute']);

// Configuración de las rutas
angularRoutingApp.config(function($routeProvider) {

    $routeProvider
      
        .when('/', {
            templateUrl : 'views/configuracion.html',
            controller  : 'configController'
        })

        .when('/institucion', {
            templateUrl : 'views/institucion.html',
            controller  : 'instiController'
        })


        .when('/modulos', {
            templateUrl : 'views/modulos.html',
            controller  : 'instiModulo'
        })

        .when('/usuarios', {
            templateUrl : 'views/usuarios.html',
            controller  : 'instiUsuario'
        })

        .otherwise({
            redirectTo: '/'
        });
});

angularRoutingApp.controller('mainController', function($scope) {
});

angularRoutingApp.controller('configController', function($scope) {
});


angularRoutingApp.controller('instiController', function($scope) {
});


angularRoutingApp.controller('instiModulo', function($scope) {

});



angularRoutingApp.controller('instiUsuario', function($scope) {

    GL_COMPONENTE_GESTOR_ELEMENTOS.ini();
    GL_COMPONENTE_CONSULTOR_ELEMENTOS.ini();

});
